import fs from 'fs';
const KEY = process.env.GEMINI_API_KEY;
if (!KEY) { console.error('GEMINI_API_KEY missing'); process.exit(1); }
const MODEL = process.env.GEMINI_MODEL || 'gemini-2.5-flash';
const SITE = process.env.SITE_URL || '';
const niches = ['real estate agents', 'clinics and doctors', 'coaching institutes', 'D2C and e-commerce stores', 'salons and spas', 'insurance agents'];
const topics = ['how missed calls silently kill leads', 'WhatsApp automation for instant replies', 'lead follow-up that never gets forgotten', 'AI agent cost versus hiring a telecaller', 'Hindi and Hinglish AI chat agents', 'appointment booking automation', 'mistakes to avoid when launching a WhatsApp chatbot'];
const posts = JSON.parse(fs.readFileSync('posts.json', 'utf8'));
const n = posts.length;
const niche = niches[n % niches.length];
const topic = topics[Math.floor(n / niches.length) % topics.length];
const prompt = `Write a helpful, original SEO blog post (700-900 words) for Indian small business owners. Niche: ${niche}. Topic: ${topic}. Write in simple Hinglish (Hindi in Roman script mixed with English). Be practical, give concrete examples, do not invent statistics or fake case studies. Output format: first line is ONLY the title. Then a blank line. Then the body as simple HTML using only <h2>, <p>, <ul>, <li>. End with a short call to action to get a free demo from Automationwala. No markdown, no code fences.`;
const res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${MODEL}:generateContent?key=${KEY}`, {
  method: 'POST', headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ contents: [{ parts: [{ text: prompt }] }] })
});
if (!res.ok) { console.error(await res.text()); process.exit(1); }
const data = await res.json();
let text = (data.candidates?.[0]?.content?.parts || []).map(p => p.text || '').join('').replace(/```html|```/g, '').trim();
const i = text.indexOf('\n');
const title = text.slice(0, i).replace(/[#*<>]/g, '').trim();
const body = text.slice(i).trim();
if (!title || body.length < 500) { console.error('Bad output'); process.exit(1); }
const date = new Date().toISOString().slice(0, 10);
const slug = title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 60) + '-' + date;
const esc = s => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/"/g, '&quot;');
const desc = body.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 150);
fs.writeFileSync(`blog/${slug}.html`, `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(title)} | Automationwala</title><meta name="description" content="${esc(desc)}"><link rel="stylesheet" href="../style.css"></head><body><header><div class="w"><b>Automationwala</b><nav><a href="../index.html">Home</a><a href="./">Blog</a></nav></div></header><main class="w"><h1>${esc(title)}</h1><p class="m">${date}</p>${body}<p><a class="btn" href="../index.html#contact">Free demo maangein</a></p></main></body></html>\n`);
posts.unshift({ title, slug, date, niche });
fs.writeFileSync('posts.json', JSON.stringify(posts, null, 1) + '\n');
const urls = ['', 'real-estate.html', 'clinics.html', 'coaching.html', 'ecommerce.html', 'blog/', ...posts.map(p => `blog/${p.slug}.html`)];
fs.writeFileSync('sitemap.xml', `<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">${urls.map(u => `<url><loc>${SITE}/${u}</loc></url>`).join('')}</urlset>\n`);
fs.writeFileSync('robots.txt', `User-agent: *\nAllow: /\nSitemap: ${SITE}/sitemap.xml\n`);
console.log('Published:', title);
